package org.labs;

import java.io.*;
import java.net.*;
import java.sql.*;

public class LibraryServer {
    private static final int PORT = 12345;
    private static Connection connection;

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Server is running on port " + PORT);

            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_db", "root", "12345");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                clientSocket.setSoTimeout(10000);
                new ClientHandler(clientSocket, connection).start();
            }

        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
}
