package org.labs;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class LibraryClient {

    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

            socket.setSoTimeout(10000);
            addAuthor(writer, reader, "John Doe");
            addBook(writer, reader, "Sample Book", "1234567890", 1);
            editBook(writer, reader, 2, "Updated Book", "0987654321", 1);
            int totalBooks = countBooks(writer, reader);
            removeBook(writer, reader, 1);
            removeAuthor(writer, reader, 1);

            System.out.println("Total number of books: " + totalBooks);
            String allBooksWithAuthors = getAllBooksWithAuthors(writer, reader);
            System.out.println("All books with authors:\n" + allBooksWithAuthors);
            String booksByAuthor = getBooksByAuthor(writer, reader, 2);
            System.out.println("Books by author:\n" + booksByAuthor);
            String allAuthors = getAllAuthors(writer, reader);
            System.out.println("All authors:\n" + allAuthors);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static void addAuthor(PrintWriter writer, BufferedReader reader, String authorName) throws InterruptedException {
        writer.println("ADD_AUTHOR," + authorName);
        Thread.sleep(1000);
        String response = receiveResponse(reader);
        System.out.println(response);
        Thread.sleep(1000);
    }

    private static void removeAuthor(PrintWriter writer, BufferedReader reader, int authorId) throws InterruptedException {
        writer.println("REMOVE_AUTHOR," + authorId);
        Thread.sleep(1000);
        String response = receiveResponse(reader);
        System.out.println(response);
    }

    private static void addBook(PrintWriter writer, BufferedReader reader, String bookTitle, String bookISBN, int authorId) throws InterruptedException {
        writer.println("ADD_BOOK," + bookTitle + "," + bookISBN + "," + authorId);
        Thread.sleep(1000);
        String response = receiveResponse(reader);
        System.out.println(response);
    }

    private static void removeBook(PrintWriter writer, BufferedReader reader, int bookId) throws InterruptedException {
        writer.println("REMOVE_BOOK," + bookId);
        Thread.sleep(1000);
        String response = receiveResponse(reader);
        System.out.println(response);
    }

    private static void editBook(PrintWriter writer, BufferedReader reader, int bookId, String newBookTitle, String newBookISBN, int newAuthorId) throws InterruptedException {
        writer.println("EDIT_BOOK," + bookId + "," + newBookTitle + "," + newBookISBN + "," + newAuthorId);
        Thread.sleep(1000);
        String response = receiveResponse(reader);
        System.out.println(response);
    }

    private static int countBooks(PrintWriter writer, BufferedReader reader) throws InterruptedException {
        writer.println("COUNT_BOOKS");
        Thread.sleep(1000);
        String response = receiveResponse(reader);

        if (response.startsWith("Error")) {
            System.out.println(response);
            return -1;
        }

        return Integer.parseInt(response.split(" ")[4]);
    }

    private static String getAllBooksWithAuthors(PrintWriter writer, BufferedReader reader) throws InterruptedException {
        writer.println("GET_ALL_BOOKS_WITH_AUTHORS");
        Thread.sleep(1000);
        return receiveResponse(reader);
    }

    private static String getBooksByAuthor(PrintWriter writer, BufferedReader reader, int authorId) throws InterruptedException {
        writer.println("GET_BOOKS_BY_AUTHOR," + authorId);
        Thread.sleep(1000);
        return receiveResponse(reader);
    }

    private static String getAllAuthors(PrintWriter writer, BufferedReader reader) throws InterruptedException {
        writer.println("GET_ALL_AUTHORS");
        Thread.sleep(1000);
        return receiveResponse(reader);
    }

    private static String receiveResponse(BufferedReader reader) {
        try {
            return reader.readLine();
        } catch (SocketTimeoutException e) {
            System.out.println("Час очікування з'єднання чи відповіді вийшов.");
            e.printStackTrace();
            return "Error receiving response.";
        }catch (IOException e) {
            e.printStackTrace();
            return "Error receiving response.";
        }
    }
}
