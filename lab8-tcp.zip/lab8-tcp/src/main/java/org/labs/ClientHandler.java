package org.labs;

import java.io.*;
import java.net.*;
import java.sql.*;

public class ClientHandler extends Thread {
    private Socket clientSocket;
    private PrintWriter writer;
    private BufferedReader reader;

    private Connection connection;

    public ClientHandler(Socket socket, Connection connection) {
        this.clientSocket = socket;
        this.connection = connection;
        try {
            writer = new PrintWriter(socket.getOutputStream(), true);
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            String request = reader.readLine();

            String response = processRequest(request);
            writer.println(response);

            reader.close();
            writer.close();
            clientSocket.close();

        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    private String processRequest(String request) throws SQLException {
        String[] parts = request.split(",");
        String operation = parts[0];

        switch (operation) {
            case "ADD_AUTHOR":
                String authorName = parts[1];
                addAuthor(authorName);
                return "Author added successfully.";

            case "REMOVE_AUTHOR":
                int authorIdToRemove = Integer.parseInt(parts[1]);
                removeAuthor(authorIdToRemove);
                return "Author removed successfully.";

            case "ADD_BOOK":
                String bookTitle = parts[1];
                String bookISBN = parts[2];
                int authorIdForBook = Integer.parseInt(parts[3]);
                addBook(bookTitle, bookISBN, authorIdForBook);
                return "Book added successfully.";

            case "REMOVE_BOOK":
                int bookIdToRemove = Integer.parseInt(parts[1]);
                removeBook(bookIdToRemove);
                return "Book removed successfully.";

            case "EDIT_BOOK":
                int bookIdToEdit = Integer.parseInt(parts[1]);
                String newBookTitle = parts[2];
                String newBookISBN = parts[3];
                int newAuthorIdForBook = Integer.parseInt(parts[4]);
                editBook(bookIdToEdit, newBookTitle, newBookISBN, newAuthorIdForBook);
                return "Book edited successfully.";

            case "COUNT_BOOKS":
                int totalBooks = countBooks();
                return "Total number of books: " + totalBooks;

            case "GET_ALL_BOOKS_WITH_AUTHORS":
                String booksWithAuthors = getAllBooksWithAuthors();
                return booksWithAuthors;

            case "GET_BOOKS_BY_AUTHOR":
                int authorId = Integer.parseInt(parts[1]);
                String booksByAuthor = getBooksByAuthor(authorId);
                return booksByAuthor;

            case "GET_ALL_AUTHORS":
                String allAuthors = getAllAuthors();
                return allAuthors;

            default:
                return "Invalid operation.";
        }
    }

    private void addAuthor(String authorName) throws SQLException {
        String sql = "INSERT INTO authors (name) VALUES (?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, authorName);
            statement.executeUpdate();
        }
    }

    private void removeAuthor(int authorId) throws SQLException {
        String sql = "DELETE FROM authors WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, authorId);
            statement.executeUpdate();
        }
    }

    private void addBook(String bookTitle, String bookISBN, int authorId) throws SQLException {
        String sql = "INSERT INTO books (title, isbn, author_id) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, bookTitle);
            statement.setString(2, bookISBN);
            statement.setInt(3, authorId);
            statement.executeUpdate();
        }
    }

    private void removeBook(int bookId) throws SQLException {
        String sql = "DELETE FROM books WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookId);
            statement.executeUpdate();
        }
    }

    private void editBook(int bookId, String newBookTitle, String newBookISBN, int newAuthorId) throws SQLException {
        String sql = "UPDATE books SET title = ?, isbn = ?, author_id = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, newBookTitle);
            statement.setString(2, newBookISBN);
            statement.setInt(3, newAuthorId);
            statement.setInt(4, bookId);
            statement.executeUpdate();
        }
    }

    private int countBooks() throws SQLException {
        String sql = "SELECT COUNT(*) FROM books";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet resultSet = statement.executeQuery();
            resultSet.next();
            return resultSet.getInt(1);
        }
    }

    private String getAllBooksWithAuthors() throws SQLException {
        StringBuilder result = new StringBuilder();
        String sql = "SELECT books.id, books.title, books.isbn, authors.name " +
                     "FROM books INNER JOIN authors ON books.author_id = authors.id";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.append("Book ID: ").append(resultSet.getInt(1)).append(", ");
                result.append("Title: ").append(resultSet.getString(2)).append(", ");
                result.append("ISBN: ").append(resultSet.getString(3)).append(", ");
                result.append("Author: ").append(resultSet.getString(4)).append("\n");
            }
        }
        return result.toString();
    }

    private String getBooksByAuthor(int authorId) throws SQLException {
        StringBuilder result = new StringBuilder();
        String sql = "SELECT id, title, isbn FROM books WHERE author_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, authorId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.append("Book ID: ").append(resultSet.getInt(1)).append(", ");
                result.append("Title: ").append(resultSet.getString(2)).append(", ");
                result.append("ISBN: ").append(resultSet.getString(3)).append("\n");
            }
        }
        return result.toString();
    }

    private String getAllAuthors() throws SQLException {
        StringBuilder result = new StringBuilder();
        String sql = "SELECT id, name FROM authors";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                result.append("Author ID: ").append(resultSet.getInt(1)).append(", ");
                result.append("Name: ").append(resultSet.getString(2)).append("\n");
            }
        }
        return result.toString();
    }
}
