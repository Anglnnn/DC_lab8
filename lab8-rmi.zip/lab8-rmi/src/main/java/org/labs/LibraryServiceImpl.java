package org.labs;

import org.labs.LibraryService;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LibraryServiceImpl extends UnicastRemoteObject implements LibraryService {
    private Connection connection;

    public LibraryServiceImpl() throws RemoteException {
        super();
        initializeDatabase();
    }

    private void initializeDatabase() {
        try {
            String jdbcUrl = "jdbc:mysql://localhost/library_db";
            String jdbcUser = "root";
            String jdbcPassword = "12345";
            connection = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);

            createTablesIfNotExists();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize the database connection.", e);
        }
    }

    private void createTablesIfNotExists() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("CREATE DATABASE IF NOT EXISTS library_db");
            statement.executeUpdate("USE library_db");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS authors (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "name VARCHAR(255) NOT NULL)");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS books (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "title VARCHAR(255) NOT NULL," +
                    "isbn VARCHAR(20) NOT NULL," +
                    "author_id INT," +
                    "FOREIGN KEY (author_id) REFERENCES authors(id) ON DELETE CASCADE)");
        }
    }

    @Override
    public void addAuthor(String name) throws RemoteException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO authors (name) VALUES (?)", Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, name);
            preparedStatement.executeUpdate();

            ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int authorId = generatedKeys.getInt(1);
                System.out.println("Author added successfully. Author ID: " + authorId);
            } else {
                System.out.println("Failed to retrieve the generated author ID.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding author: " + e.getMessage());
        }
    }

    @Override
    public void removeAuthor(int authorId) throws RemoteException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM authors WHERE id = ?")) {
            preparedStatement.setInt(1, authorId);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Author removed successfully.");
            } else {
                System.out.println("Author not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error removing author: " + e.getMessage());
        }
    }

    @Override
    public void addBook(String title, String isbn, int authorId) throws RemoteException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO books (title, isbn, author_id) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, title);
            preparedStatement.setString(2, isbn);
            preparedStatement.setInt(3, authorId);
            preparedStatement.executeUpdate();

            ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int bookId = generatedKeys.getInt(1);
                System.out.println("Book added successfully. Book ID: " + bookId);
            } else {
                System.out.println("Failed to retrieve the generated book ID.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding book: " + e.getMessage());
        }
    }

    @Override
    public void removeBook(int bookId) throws RemoteException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM books WHERE id = ?")) {
            preparedStatement.setInt(1, bookId);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Book removed successfully.");
            } else {
                System.out.println("Book not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error removing book: " + e.getMessage());
        }
    }

    @Override
    public void editBook(int bookId, String title, String isbn, int authorId) throws RemoteException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE books SET title = ?, isbn = ?, author_id = ? WHERE id = ?")) {
            preparedStatement.setString(1, title);
            preparedStatement.setString(2, isbn);
            preparedStatement.setInt(3, authorId);
            preparedStatement.setInt(4, bookId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Book edited successfully.");
            } else {
                System.out.println("Book not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error editing book: " + e.getMessage());
        }
    }

    @Override
    public int countBooks() throws RemoteException {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM books")) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("Error counting books: " + e.getMessage());
        }
        return -1;
    }

    @Override
    public List<String> getAllBooksWithAuthors() throws RemoteException {
        List<String> result = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT books.id, books.title, books.isbn, authors.name " +
                     "FROM books INNER JOIN authors ON books.author_id = authors.id")) {
            while (resultSet.next()) {
                int bookId = resultSet.getInt("id");
                String bookTitle = resultSet.getString("title");
                String bookIsbn = resultSet.getString("isbn");
                String authorName = resultSet.getString("name");
                result.add("Book ID: " + bookId + ", Title: " + bookTitle + ", ISBN: " + bookIsbn + ", Author: " + authorName);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving books with authors: " + e.getMessage());
        }
        return result;
    }

    @Override
    public List<String> getBooksByAuthor(int authorId) throws RemoteException {
        List<String> result = new ArrayList<>();
        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT id, title, isbn FROM books WHERE author_id = ?");
             ResultSet resultSet = preparedStatement.executeQuery()) {
            preparedStatement.setInt(1, authorId);
            while (resultSet.next()) {
                int bookId = resultSet.getInt("id");
                String bookTitle = resultSet.getString("title");
                String bookIsbn = resultSet.getString("isbn");
                result.add("Book ID: " + bookId + ", Title: " + bookTitle + ", ISBN: " + bookIsbn);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving books by author: " + e.getMessage());
        }
        return result;
    }

    @Override
    public List<String> getAllAuthors() throws RemoteException {
        List<String> result = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT id, name FROM authors")) {
            while (resultSet.next()) {
                int authorId = resultSet.getInt("id");
                String authorName = resultSet.getString("name");
                result.add("Author ID: " + authorId + ", Name: " + authorName);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving authors: " + e.getMessage());
        }
        return result;
    }

    public static void main(String[] args) {
        try {
            LibraryService libraryService = new LibraryServiceImpl();
            java.rmi.registry.LocateRegistry.createRegistry(8080);
            java.rmi.Naming.rebind("LibraryService", libraryService);
            System.out.println("Server is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
