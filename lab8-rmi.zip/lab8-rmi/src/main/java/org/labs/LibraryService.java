package org.labs;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface LibraryService extends Remote {
    void addAuthor(String name) throws RemoteException;
    void removeAuthor(int authorId) throws RemoteException;
    void addBook(String title, String isbn, int authorId) throws RemoteException;
    void removeBook(int bookId) throws RemoteException;
    void editBook(int bookId, String title, String isbn, int authorId) throws RemoteException;
    int countBooks() throws RemoteException;
    List<String> getAllBooksWithAuthors() throws RemoteException;
    List<String> getBooksByAuthor(int authorId) throws RemoteException;
    List<String> getAllAuthors() throws RemoteException;
}
