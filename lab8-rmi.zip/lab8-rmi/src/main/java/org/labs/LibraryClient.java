package org.labs;

import java.rmi.Naming;
import java.util.List;

public class LibraryClient {
    public static void main(String[] args) {
        try {
            LibraryService libraryService = (LibraryService) Naming.lookup("rmi://localhost/LibraryService");


            libraryService.addAuthor("John Doe");
            libraryService.addBook("Sample Book", "1234567890", 1);
            libraryService.editBook(2, "Updated Book", "0987654321", 1);
            int totalBooks = libraryService.countBooks();
            libraryService.removeBook(1);
            libraryService.removeAuthor(1);


            System.out.println("Total number of books: " + totalBooks);
            List<String> allBooksWithAuthors = libraryService.getAllBooksWithAuthors();
            System.out.println("All books with authors:\n" + allBooksWithAuthors);
            List<String> booksByAuthor = libraryService.getBooksByAuthor(1);
            System.out.println("Books by author:\n" + booksByAuthor);
            List<String> allAuthors = libraryService.getAllAuthors();
            System.out.println("All authors:\n" + allAuthors);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
